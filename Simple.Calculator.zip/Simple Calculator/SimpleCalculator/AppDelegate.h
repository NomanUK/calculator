//
//  AppDelegate.h
//  Calculator
//
//  Created by Noman Vasi on 28/01/2016.
//  Copyright © 2016 Noman Vasi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
