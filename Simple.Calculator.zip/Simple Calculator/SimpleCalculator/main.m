//
//  main.m
//  Calculator
//
//  Created by Noman Vasi on 28/01/2016.
//  Copyright © 2016 Noman Vasi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
